<!DOCTYPE html>
<html>
<head>
  <title>Sign-Up Page</title>
  
  <!-- Include the CSS stylesheet for styling -->
  <link rel="stylesheet" href="Style/Form-Style.css">
</head>
<body>
    <!-- Container for the sign-up form -->
    <div class="container">
        <!-- Sign-up form -->
        <form action="functions.php" method="POST" class="signup">
            <h2>Sign-Up Page</h2>
            <!-- Username input -->
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <!-- Password input -->
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <!-- Submit button to submit the form -->
            <button type="submit" name="signup">Sign Up</button><br>
            <!-- Link to the login page -->
            <a href="index.php" style="text-decoration: none;">Go to login page!</a>
        </form>
    </div>
</body>
</html>
