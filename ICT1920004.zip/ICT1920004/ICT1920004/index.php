<?php
// Start the session to manage user data across pages
session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login Page</title>
  
  <!-- Include the CSS stylesheet for styling -->
  <link rel="stylesheet" href="Style/Form-Style.css">
</head>
<body>
    <!-- Container for the login form -->
    <div class="container">
        <!-- Login form -->
        <form action="functions.php" method="POST" class="login">
            <h2>Login Page</h2>
            <!-- Username input -->
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <!-- Password input -->
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <!-- Submit button to submit the form -->
            <button type="submit" name="login">Log In</button><br>
            <!-- Link to the Sign-Up page -->
            <a href="signup.php" style="text-decoration: none;">Go to Sign-Up page!</a><br>
            <!-- Link to the Admin login page -->
            <a href="Admin/admin-login.php" style="text-decoration: none;">Login as Admin!</a><br>

            <?php
            // Check if there are any error messages in the session
            if (isset($_SESSION['error_message'])) {
                // Display the error message in a box
                echo '<div class="error-box">' . $_SESSION['error_message'] . '</div>';
                // Clear the error message after displaying it once
                unset($_SESSION['error_message']);
            }
            ?>

        </form>
    </div>
</body>
</html>
