<?php
// Functions definition

// Function to connect to the database
function connectDatabase()
{
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ict1920004";

    // Create connection
    $conn = mysqli_connect($hostname, $username, $password, $dbname);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    return $conn;
}

// Function to retrieve contact messages from the database
function getContactMessages()
{
    $conn = connectDatabase();

    $sql = "SELECT * FROM contact";
    $result = mysqli_query($conn, $sql);
    $messages = array();

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $messages[] = $row;
        }
    }

    mysqli_close($conn);
    return $messages;
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Contact Messages</title>
    <link rel='stylesheet' href="../Style/Admin-Style.css">
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <img src="../Image/dp.png" alt="Company Logo">
            <h1>Amana Azmeer</h1>
            <h6>Software Engineer</h6>
        </div>
        <a href="admin.php">Submit Project</a>
        <a href="contact.php">Contact Message</a>
        <form method="post" action="">
            <div style="text-align: center;margin: 0px">
                <input type="submit" name="logout" value="Logout">
            </div>
        </form>
    </div>

    <?php
    // Logout functionality (optional)
    if (isset($_POST["logout"])) {
        // Destroy the session
        session_destroy();
        
        // Redirect to the login page or any other page after logout
        header("Location: admin-login.php");
        exit;
    }
    ?>

    <div class="content">
        <div id="project-list">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                </tr>
                <?php
                // Retrieve data from the "contact" table and display it in the table
                $messages = getContactMessages();
                foreach ($messages as $row) {
                    echo "<tr>";
                    echo "<td>{$row['Contact_Id']}</td>";
                    echo "<td>{$row['Name']}</td>";
                    echo "<td>{$row['Email']}</td>";
                    echo "<td>{$row['Message']}</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>
